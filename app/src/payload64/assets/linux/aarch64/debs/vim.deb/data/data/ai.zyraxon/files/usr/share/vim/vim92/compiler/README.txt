ZYRAXON AI — Copyright (c) 2026 onelpawarai. All rights reserved.
Distributed under the ZYRAXON Sovereign License, X Edition (ZSL-X).
See LICENSE in the repository root.

This directory contains Vim scripts to be used with a specific compiler.
They are used with the ":compiler" command.

These scripts usually set options, for example 'errorformat'.
See ":help write-compiler-plugin".

To undo the effect of a compiler plugin, use the make compiler plugin.

If you want to write your own compiler plugin, have a look at the other files
for how to do it, the format is simple.

If you think a compiler plugin you have written is useful for others, please
send it to the vim-dev mailing list: <vim-dev@vim.org>
