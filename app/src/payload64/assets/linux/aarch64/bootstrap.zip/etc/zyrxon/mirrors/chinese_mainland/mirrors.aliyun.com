# This file is sourced by pkg
# Mirror by Alibaba Open Source Mirror Site
WEIGHT=1
MAIN="https://mirrors.aliyun.com/zyrxon/termux-main"
ROOT="https://mirrors.aliyun.com/zyrxon/termux-root"
X11="https://mirrors.aliyun.com/zyrxon/zyrxon-x11"
