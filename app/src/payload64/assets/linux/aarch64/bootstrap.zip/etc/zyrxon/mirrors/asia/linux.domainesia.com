# This file is sourced by pkg
# Mirror by DomaiNesia, hosted in Indonesia
WEIGHT=1
MAIN="https://linux.domainesia.com/applications/zyrxon/termux-main"
ROOT="https://linux.domainesia.com/applications/zyrxon/termux-root"
X11="https://linux.domainesia.com/applications/zyrxon/zyrxon-x11"
