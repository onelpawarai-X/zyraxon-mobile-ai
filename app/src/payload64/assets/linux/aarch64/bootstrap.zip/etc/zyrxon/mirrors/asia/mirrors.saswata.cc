# This file is sourced by pkg
# Mirror by saswatasarkar13, hosted in India
WEIGHT=1
MAIN="https://mirrors.saswata.cc/zyrxon/termux-main"
ROOT="https://mirrors.saswata.cc/zyrxon/termux-root"
X11="https://mirrors.saswata.cc/zyrxon/zyrxon-x11"
