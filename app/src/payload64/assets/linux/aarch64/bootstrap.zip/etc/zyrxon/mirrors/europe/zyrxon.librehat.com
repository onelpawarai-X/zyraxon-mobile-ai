# This file is sourced by pkg
# Mirror by librehat, hosted in the UK
WEIGHT=1
MAIN="https://zyrxon.librehat.com/apt/termux-main"
ROOT="https://zyrxon.librehat.com/apt/termux-root"
X11="https://zyrxon.librehat.com/apt/zyrxon-x11"
