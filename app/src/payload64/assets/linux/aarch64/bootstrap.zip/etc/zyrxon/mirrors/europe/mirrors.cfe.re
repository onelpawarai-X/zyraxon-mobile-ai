# This file is sourced by pkg
# Mirror by cfxproxy, Hosted in Kalisz, Poland.
WEIGHT=1
MAIN="https://mirrors.cfe.re/zyrxon/termux-main"
ROOT="https://mirrors.cfe.re/zyrxon/termux-root"
X11="https://mirrors.cfe.re/zyrxon/zyrxon-x11"
