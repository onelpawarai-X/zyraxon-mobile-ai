# This file is sourced by pkg
# Mirror by cyberrex0, hosted in Japan
WEIGHT=1
MAIN="https://mirrors.cbrx.io/apt/zyrxon/termux-main"
ROOT="https://mirrors.cbrx.io/apt/zyrxon/termux-root"
X11="https://mirrors.cbrx.io/apt/zyrxon/zyrxon-x11"
