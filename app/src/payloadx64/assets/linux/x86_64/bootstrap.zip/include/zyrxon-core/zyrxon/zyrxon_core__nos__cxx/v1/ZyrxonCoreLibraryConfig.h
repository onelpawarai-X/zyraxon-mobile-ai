#ifndef LIBZYRXON_CORE__NOS__CXX__ZYRXON_CORE_LIBRARY_CONFIG___H
#define LIBZYRXON_CORE__NOS__CXX__ZYRXON_CORE_LIBRARY_CONFIG___H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif



/** Get `sIsRunningTests`. */
bool libzyrxon_core__nos__cxx__getIsRunningTests();

/** Set `sIsRunningTests`. */
void libzyrxon_core__nos__cxx__setIsRunningTests(bool isRunningTests);



#ifdef __cplusplus
}
#endif

#endif // LIBZYRXON_CORE__NOS__CXX__ZYRXON_CORE_LIBRARY_CONFIG___H
