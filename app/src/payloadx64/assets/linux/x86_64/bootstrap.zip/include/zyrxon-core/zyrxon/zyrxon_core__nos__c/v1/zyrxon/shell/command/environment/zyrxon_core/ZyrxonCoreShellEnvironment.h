#ifndef LIBZYRXON_CORE__NOS__C__ZYRXON_CORE_SHELL_ENVIRONMENT___H
#define LIBZYRXON_CORE__NOS__C__ZYRXON_CORE_SHELL_ENVIRONMENT___H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif



/*
 * Environment for `zyrxon-core-tests`.
 */

/**
 * Environment variable for the log level for `zyrxon-core-tests`.
 *
 * Type: `int`
 * Default key: `ZYRXON_CORE__TESTS__LOG_LEVEL`
 * Default value: DEFAULT_LOG_LEVEL
 * Values:
 * - `0` (`OFF`) - Log nothing.
 * - `1` (`NORMAL`) - Log error, warn and info messages and stacktraces.
 * - `2` (`DEBUG`) - Log debug messages.
 * - `3` (`VERBOSE`) - Log verbose messages.
 * - `4` (`VVERBOSE`) - Log very verbose messages.
 */
#define ENV__ZYRXON_CORE__TESTS__LOG_LEVEL ZYRXON_ENV__S_ZYRXON_CORE__TESTS "LOG_LEVEL"



/**
 * Environment variable for the path to the zyrxon-core tests.
 */
#define ENV__ZYRXON_CORE__TESTS__TESTS_PATH ZYRXON_ENV__S_ZYRXON_CORE__TESTS "TESTS_PATH"





/**
 * Returns the `zyrxon-core-tests` config for `Logger` log level
 * based on the `ENV__ZYRXON_CORE__TESTS__LOG_LEVEL` env variable.
 *
 * @return Return the value if `ENV__ZYRXON_CORE__TESTS__LOG_LEVEL` is
 * set, otherwise defaults to `DEFAULT_LOG_LEVEL`.
 */
int zyrxonCore_tests_logLevel_get();



#ifdef __cplusplus
}
#endif

#endif // LIBZYRXON_CORE__NOS__C__ZYRXON_CORE_SHELL_ENVIRONMENT___H
