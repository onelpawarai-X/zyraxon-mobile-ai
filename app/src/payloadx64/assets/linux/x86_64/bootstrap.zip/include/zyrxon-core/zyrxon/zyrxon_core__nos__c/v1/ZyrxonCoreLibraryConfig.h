#ifndef LIBZYRXON_CORE__NOS__C__ZYRXON_CORE_LIBRARY_CONFIG___H
#define LIBZYRXON_CORE__NOS__C__ZYRXON_CORE_LIBRARY_CONFIG___H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif



/** Get `sIsRunningTests`. */
bool libzyrxon_core__nos__c__getIsRunningTests();

/** Set `sIsRunningTests`. */
void libzyrxon_core__nos__c__setIsRunningTests(bool isRunningTests);



#ifdef __cplusplus
}
#endif

#endif // LIBZYRXON_CORE__NOS__C__ZYRXON_CORE_LIBRARY_CONFIG___H
