#ifndef LIBZYRXON_EXEC__NOS__C__ZYRXON_EXEC_LIBRARY_CONFIG___H
#define LIBZYRXON_EXEC__NOS__C__ZYRXON_EXEC_LIBRARY_CONFIG___H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif



/** Get `sIsRunningTests`. */
bool libzyrxon_exec__nos__c__getIsRunningTests();

/** Set `sIsRunningTests`. */
void libzyrxon_exec__nos__c__setIsRunningTests(bool isRunningTests);



#ifdef __cplusplus
}
#endif

#endif // LIBZYRXON_EXEC__NOS__C__ZYRXON_EXEC_LIBRARY_CONFIG___H
