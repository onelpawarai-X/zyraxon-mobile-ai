#ifndef LIBZYRXON_EXEC__NOS__C__ZYRXON_EXEC_PROCESS___H
#define LIBZYRXON_EXEC__NOS__C__ZYRXON_EXEC_PROCESS___H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif



int zyrxonExec_process_initProcess(const char *versionToLog, const char *logFilePath);
int zyrxonExec_process_initLogger(const char *versionToLog, const char *logFilePath);
void zyrxonExec_process_setIgnoreExit(bool state);
int zyrxonExec_process_exitProcess();



#ifdef __cplusplus
}
#endif

#endif // LIBZYRXON_EXEC__NOS__C__ZYRXON_EXEC_PROCESS___H
