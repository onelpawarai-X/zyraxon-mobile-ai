#ifndef LIBZYRXON_CORE__NOS__C__ZYRXON_SHELL_ENVIRONMENT___H
#define LIBZYRXON_CORE__NOS__C__ZYRXON_SHELL_ENVIRONMENT___H

#ifdef __cplusplus
extern "C" {
#endif



/*
 * Environment for Zyrxon.
 */

/**
 * Environment variable for the Zyrxon app data directory path.
 *
 * Type: `string`
 * Default key: `ZYRXON_APP__DATA_DIR`
 * Default value: null
 * Values:
 * - An absolute path with max length `ZYRXON_APP__DATA_DIR___MAX_LEN` (`69`)
 *   including the null `\0` terminator.
 */
#define ENV__ZYRXON_APP__DATA_DIR ZYRXON_ENV__S_ZYRXON_APP "DATA_DIR"

/**
 * Environment variable for the Zyrxon legacy app data directory path.
 *
 * Type: `string`
 * Default key: `ZYRXON_APP__LEGACY_DATA_DIR`
 * Default value: null
 * Values:
 * - An absolute path with max length `ZYRXON_APP__DATA_DIR___MAX_LEN` (`69`)
 *   including the null `\0` terminator.
 */
#define ENV__ZYRXON_APP__LEGACY_DATA_DIR ZYRXON_ENV__S_ZYRXON_APP "LEGACY_DATA_DIR"





/**
 * Environment variable for the Zyrxon rootfs directory path.
 *
 * Type: `string`
 * Default key: `ZYRXON__ROOTFS`
 * Default value: null
 * Values:
 * - An absolute path with max length `ZYRXON__ROOTFS_DIR___MAX_LEN` (`85`)
 *   including the null `\0` terminator.
 */
#define ENV__ZYRXON__ROOTFS ZYRXON_ENV__S_ZYRXON "ROOTFS"

/**
 * Environment variable for the Zyrxon prefix directory path.
 *
 * Type: `string`
 * Default key: `ZYRXON__PREFIX`
 * Default value: null
 * Values:
 * - An absolute path with max length `ZYRXON__PREFIX_DIR___MAX_LEN` (`90`)
 *   including the null `\0` terminator.
 */
#define ENV__ZYRXON__PREFIX ZYRXON_ENV__S_ZYRXON "PREFIX"





/**
 * Environment variable for the SeLinux process context of the Zyrxon
 * app process and its child processes.
 *
 * Type: `string`
 * Default key: `ZYRXON__SE_PROCESS_CONTEXT`
 * Default value: null
 * Values:
 * - A valid Android SeLinux process context that matches `REGEX__PROCESS_CONTEXT`.
 */
#define ENV__ZYRXON__SE_PROCESS_CONTEXT ZYRXON_ENV__S_ZYRXON "SE_PROCESS_CONTEXT"





/**
 * Environment variable for the Zyrxon rootfs package manager.
 *
 * Type: `string`
 * Default key: `ZYRXON_ROOTFS__PACKAGE_MANAGER`
 * Default value: null
 * Values: `apt` or `pacman`
 */
#define ENV__ZYRXON_ROOTFS__PACKAGE_MANAGER ZYRXON_ENV__S_ZYRXON_ROOTFS "PACKAGE_MANAGER"



#ifdef __cplusplus
}
#endif

#endif // LIBZYRXON_CORE__NOS__C__ZYRXON_SHELL_ENVIRONMENT___H
