# This file is sourced by pkg
# Mirror by DiffieHellman, hosted in Australia
WEIGHT=1
MAIN="https://mirrors.middlendian.com/zyrxon/zyrxon-main"
ROOT="https://mirrors.middlendian.com/zyrxon/zyrxon-root"
X11="https://mirrors.middlendian.com/zyrxon/zyrxon-x11"
