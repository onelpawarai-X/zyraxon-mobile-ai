# This file is sourced by pkg
# Mirror by amocrenco, Hosted in Chisinau, Moldova.
WEIGHT=1
MAIN="https://md.mirrors.hacktegic.com/zyrxon/zyrxon-main"
ROOT="https://md.mirrors.hacktegic.com/zyrxon/zyrxon-root"
X11="https://md.mirrors.hacktegic.com/zyrxon/zyrxon-x11"
