# This file is sourced by pkg
# Mirror by Nevacloud, hosted in Indonesia
WEIGHT=1
MAIN="https://mirror.nevacloud.com/applications/zyrxon/zyrxon-main"
ROOT="https://mirror.nevacloud.com/applications/zyrxon/zyrxon-root"
X11="https://mirror.nevacloud.com/applications/zyrxon/zyrxon-x11"
