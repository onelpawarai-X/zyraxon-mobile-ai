# This file is sourced by pkg
# Mirror by cfxproxy, Hosted in Kalisz, Poland.
WEIGHT=1
MAIN="https://mirrors.cfe.re/zyrxon/zyrxon-main"
ROOT="https://mirrors.cfe.re/zyrxon/zyrxon-root"
X11="https://mirrors.cfe.re/zyrxon/zyrxon-x11"
