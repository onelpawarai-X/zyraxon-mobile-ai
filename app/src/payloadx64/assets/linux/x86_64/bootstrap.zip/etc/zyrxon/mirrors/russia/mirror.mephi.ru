# This file is sourced by pkg
# Mirrors by National Research Nuclear University MEPhI
WEIGHT=1
MAIN="http://mirror.mephi.ru/zyrxon/zyrxon-main"
ROOT="http://mirror.mephi.ru/zyrxon/zyrxon-root"
X11="http://mirror.mephi.ru/zyrxon/zyrxon-x11"
