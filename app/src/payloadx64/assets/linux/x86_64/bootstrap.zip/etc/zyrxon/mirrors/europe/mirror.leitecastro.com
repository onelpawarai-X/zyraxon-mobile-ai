# This file is sourced by pkg
# Mirror by Tomás Leite de Castro, hosted in Lisbon, Portugal.
WEIGHT=1
MAIN="https://mirror.leitecastro.com/zyrxon/zyrxon-main"
ROOT="https://mirror.leitecastro.com/zyrxon/zyrxon-root"
X11="https://mirror.leitecastro.com/zyrxon/zyrxon-x11"
