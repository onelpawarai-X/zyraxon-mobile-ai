# This file is sourced by pkg
# Mirror by vern.cc
WEIGHT=1
MAIN="https://mirror.vern.cc/zyrxon/zyrxon-main"
ROOT="https://mirror.vern.cc/zyrxon/zyrxon-root"
X11="https://mirror.vern.cc/zyrxon/zyrxon-x11"
