if [ ! -f /data/data/ai.zyraxon/files/home/.config/zyrxon/zyrxon.properties ] && [ ! -e /data/data/ai.zyraxon/files/home/.zyrxon/zyrxon.properties ]; then
	mkdir -p /data/data/ai.zyraxon/files/home/.zyrxon
	cp /data/data/ai.zyraxon/files/usr/share/examples/zyrxon/zyrxon.properties /data/data/ai.zyraxon/files/home/.zyrxon/
fi
