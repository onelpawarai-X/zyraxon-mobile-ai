##
## This script is sourced by /data/data/ai.zyraxon/files/usr/bin/login before executing shell.
##
