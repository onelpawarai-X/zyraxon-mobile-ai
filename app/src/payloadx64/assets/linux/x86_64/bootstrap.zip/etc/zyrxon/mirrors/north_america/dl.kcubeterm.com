# This file is sourced by pkg
# Mirror by Kcubeterm, in California, US
WEIGHT=1
MAIN="https://dl.kcubeterm.com/zyrxon-main"
ROOT="https://dl.kcubeterm.com/zyrxon-root"
X11="https://dl.kcubeterm.com/zyrxon-x11"
